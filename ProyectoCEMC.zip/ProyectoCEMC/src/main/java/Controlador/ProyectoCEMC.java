package Controlador;
import Vista.Login;

public class ProyectoCEMC {
    public static void main(String[] args) {
        Login m1 = new Login();
        m1.setVisible(true);
        m1.setLocationRelativeTo(null);
    }
}
